package com.revature.service;

public interface CommonService {

	public void removeSessionMessage();

}
