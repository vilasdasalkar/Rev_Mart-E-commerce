package com.revature.util;

public class SecurityConstant {

	public static final long UNLOCK_DURATION_TIME = 3000;

	public static final long ATTEMPT_TIME = 3;
}
